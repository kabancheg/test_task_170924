from django.contrib import admin

from .models import LogItem


admin.site.register(LogItem)
